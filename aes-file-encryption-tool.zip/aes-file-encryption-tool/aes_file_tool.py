#!/usr/bin/env python3
"""Password-based AES-GCM file encryption for learning and personal testing."""
import argparse
import getpass
import os
import sys
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

MAGIC = b"VAE1"
SALT_SIZE = 16
NONCE_SIZE = 12
KEY_SIZE = 32


def derive_key(password: str, salt: bytes) -> bytes:
    if not password:
        raise ValueError("Password cannot be empty.")
    kdf = Scrypt(salt=salt, length=KEY_SIZE, n=2**14, r=8, p=1)
    return kdf.derive(password.encode("utf-8"))


def encrypt_file(source: Path, password: str) -> Path:
    if not source.is_file():
        raise FileNotFoundError(f"File not found: {source}")
    salt = os.urandom(SALT_SIZE)
    nonce = os.urandom(NONCE_SIZE)
    key = derive_key(password, salt)
    ciphertext = AESGCM(key).encrypt(nonce, source.read_bytes(), None)
    output = source.with_name(source.name + ".enc")
    output.write_bytes(MAGIC + salt + nonce + ciphertext)
    return output


def decrypt_file(source: Path, password: str) -> Path:
    if not source.is_file():
        raise FileNotFoundError(f"File not found: {source}")
    blob = source.read_bytes()
    minimum = len(MAGIC) + SALT_SIZE + NONCE_SIZE + 16
    if len(blob) < minimum or not blob.startswith(MAGIC):
        raise ValueError("This does not look like a supported encrypted file.")
    offset = len(MAGIC)
    salt = blob[offset:offset + SALT_SIZE]
    offset += SALT_SIZE
    nonce = blob[offset:offset + NONCE_SIZE]
    ciphertext = blob[offset + NONCE_SIZE:]
    key = derive_key(password, salt)
    plaintext = AESGCM(key).decrypt(nonce, ciphertext, None)
    output = source.with_name(source.name.removesuffix(".enc") + ".decrypted")
    output.write_bytes(plaintext)
    return output


def main() -> int:
    parser = argparse.ArgumentParser(description="Encrypt/decrypt a file using AES-GCM.")
    parser.add_argument("action", choices=("encrypt", "decrypt"))
    parser.add_argument("file", type=Path)
    args = parser.parse_args()
    password = getpass.getpass("Password: ")
    try:
        result = encrypt_file(args.file, password) if args.action == "encrypt" else decrypt_file(args.file, password)
        print(f"Success. Output saved to: {result}")
        return 0
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
