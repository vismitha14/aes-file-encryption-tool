# AES File Encryption & Decryption Tool

A small Python command-line project that encrypts files with AES-GCM and decrypts them when given the correct password.

## Features
- Password-based key derivation with Scrypt
- AES-GCM authenticated encryption
- Random salt and nonce for each encryption
- Detects an incorrect password or modified encrypted file

## Requirements
- Python 3.9+
- `cryptography`

## Setup
```bash
python -m pip install -r requirements.txt
```

## Usage
Encrypt a file:
```bash
python aes_file_tool.py encrypt notes.txt
```
Decrypt it:
```bash
python aes_file_tool.py decrypt notes.txt.enc
```
The tool prompts for a password. Keep it safe: losing it means the encrypted file cannot be recovered.

## Format
The output file contains a short header, a random salt, a nonce, and the AES-GCM ciphertext.

## Security note
This is an educational project. Test it on copies of non-sensitive files first. It does not securely erase the original file.
